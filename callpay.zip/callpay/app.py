"""
CallPay - collect payments by phone call, watch them live.

Flow
 1. Customer calls your Twilio number.
 2. IVR asks: "Enter the amount in rupees, then press hash."
 3. App creates a Razorpay Payment Link and SMSes it to the caller.
 4. Dashboard shows caller number + requested amount instantly (Server-Sent Events).
 5. When the caller pays, Razorpay webhook marks it PAID and the dashboard updates live.

The CALLER always approves the payment themselves (UPI/card/netbanking on Razorpay's page).
"""
import hashlib, hmac, json, os, queue, secrets, sqlite3, time
from datetime import datetime
from functools import wraps

import requests
from dotenv import load_dotenv
from flask import (Flask, Response, abort, jsonify, render_template, request,
                   stream_with_context)
from twilio.request_validator import RequestValidator
from twilio.twiml.voice_response import Gather, VoiceResponse

load_dotenv()
app = Flask(__name__)

DB = os.getenv("DB_PATH", "callpay.db")
DASH_USER = os.getenv("DASHBOARD_USER", "admin")
DASH_PASS = os.getenv("DASHBOARD_PASSWORD", "change-me")
TWILIO_TOKEN = os.getenv("TWILIO_AUTH_TOKEN", "")
BASE_URL = os.getenv("PUBLIC_BASE_URL", "").rstrip("/")
RZP_KEY = os.getenv("RAZORPAY_KEY_ID", "")
RZP_SECRET = os.getenv("RAZORPAY_KEY_SECRET", "")
RZP_WEBHOOK_SECRET = os.getenv("RAZORPAY_WEBHOOK_SECRET", "")
MAX_AMOUNT = int(os.getenv("MAX_AMOUNT_INR", "5000"))
DEMO = os.getenv("DEMO_MODE", "0") == "1"
SAY = {"voice": "Polly.Aditi", "language": "en-IN"}

# ---------------------------------------------------------------- database
def db():
    c = sqlite3.connect(DB)
    c.row_factory = sqlite3.Row
    return c

def init_db():
    with db() as c:
        c.execute("""CREATE TABLE IF NOT EXISTS requests(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            caller TEXT NOT NULL,
            amount INTEGER NOT NULL,
            status TEXT NOT NULL DEFAULT 'REQUESTED',
            link_id TEXT, link_url TEXT,
            created_at TEXT NOT NULL, paid_at TEXT)""")

def row(r):
    return dict(r) if r else None

# ---------------------------------------------------------------- live events (SSE)
subscribers = set()

def publish(evt):
    for q in list(subscribers):
        q.put(evt)

@app.get("/events")
def events():
    auth_required()
    q = queue.Queue()
    subscribers.add(q)

    @stream_with_context
    def stream():
        try:
            yield "retry: 3000\n\n"
            while True:
                try:
                    yield f"data: {json.dumps(q.get(timeout=15))}\n\n"
                except queue.Empty:
                    yield ": keepalive\n\n"
        finally:
            subscribers.discard(q)

    return Response(stream(), mimetype="text/event-stream",
                    headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})

# ---------------------------------------------------------------- auth helpers
def auth_required():
    a = request.authorization
    ok = a and secrets.compare_digest(a.username, DASH_USER) \
        and secrets.compare_digest(a.password or "", DASH_PASS)
    if not ok:
        abort(Response("Login required", 401, {"WWW-Authenticate": 'Basic realm="CallPay"'}))

def dashboard(f):
    @wraps(f)
    def w(*a, **k):
        auth_required()
        return f(*a, **k)
    return w

def twilio_only(f):
    """Reject requests that were not signed by Twilio (skipped in demo mode)."""
    @wraps(f)
    def w(*a, **k):
        if TWILIO_TOKEN and BASE_URL:
            sig = request.headers.get("X-Twilio-Signature", "")
            url = BASE_URL + request.full_path.rstrip("?")
            if not RequestValidator(TWILIO_TOKEN).validate(url, request.form, sig):
                abort(403)
        elif not DEMO:
            abort(503, "Set TWILIO_AUTH_TOKEN and PUBLIC_BASE_URL")
        return f(*a, **k)
    return w

# ---------------------------------------------------------------- payment link
def create_payment_link(req_id, caller, amount):
    if not (RZP_KEY and RZP_SECRET):
        if not DEMO:
            raise RuntimeError("Razorpay keys missing")
        return f"demo_{req_id}", f"{BASE_URL or request.host_url.rstrip('/')}/demo/pay/{req_id}"
    r = requests.post(
        "https://api.razorpay.com/v1/payment_links",
        auth=(RZP_KEY, RZP_SECRET), timeout=15,
        json={
            "amount": amount * 100,            # paise
            "currency": "INR",
            "description": f"Payment request #{req_id}",
            "reference_id": f"callpay-{req_id}",
            "customer": {"contact": caller},
            "notify": {"sms": True},           # Razorpay texts the link to the caller
            "expire_by": int(time.time()) + 30 * 60,
        })
    r.raise_for_status()
    d = r.json()
    return d["id"], d["short_url"]

# ---------------------------------------------------------------- Twilio voice (IVR)
@app.post("/voice")
@twilio_only
def voice():
    vr = VoiceResponse()
    g = Gather(input="dtmf", action="/voice/amount", method="POST",
               finish_on_key="#", timeout=8, num_digits=6)
    g.say("Welcome. Enter the amount in rupees you want to pay, then press hash.", **SAY)
    vr.append(g)
    vr.say("We did not receive any input. Goodbye.", **SAY)
    return Response(str(vr), mimetype="text/xml")

@app.post("/voice/amount")
@twilio_only
def voice_amount():
    vr = VoiceResponse()
    caller = request.form.get("From", "unknown")
    digits = request.form.get("Digits", "")
    if not digits.isdigit() or not (1 <= int(digits) <= MAX_AMOUNT):
        vr.say(f"Sorry, please call again and enter an amount between 1 and {MAX_AMOUNT} rupees.", **SAY)
        return Response(str(vr), mimetype="text/xml")
    amount = int(digits)

    with db() as c:
        cur = c.execute("INSERT INTO requests(caller,amount,created_at) VALUES(?,?,?)",
                        (caller, amount, datetime.now().isoformat(timespec="seconds")))
        rid = cur.lastrowid
    # show on dashboard immediately, before the link is even created
    publish({"type": "request", "data": row(db().execute("SELECT * FROM requests WHERE id=?", (rid,)).fetchone())})

    try:
        link_id, link_url = create_payment_link(rid, caller, amount)
        with db() as c:
            c.execute("UPDATE requests SET link_id=?, link_url=?, status='LINK_SENT' WHERE id=?",
                      (link_id, link_url, rid))
        publish({"type": "update", "data": row(db().execute("SELECT * FROM requests WHERE id=?", (rid,)).fetchone())})
        vr.say(f"Thank you. A payment link for {amount} rupees has been sent to your phone by S M S. Goodbye.", **SAY)
    except Exception as e:
        app.logger.exception("payment link failed")
        with db() as c:
            c.execute("UPDATE requests SET status='FAILED' WHERE id=?", (rid,))
        publish({"type": "update", "data": row(db().execute("SELECT * FROM requests WHERE id=?", (rid,)).fetchone())})
        vr.say("Sorry, something went wrong. Please try again later.", **SAY)
    return Response(str(vr), mimetype="text/xml")

# ---------------------------------------------------------------- Razorpay webhook
def mark_paid(where_sql, value):
    with db() as c:
        c.execute(f"UPDATE requests SET status='PAID', paid_at=? WHERE {where_sql} AND status!='PAID'",
                  (datetime.now().isoformat(timespec="seconds"), value))
        r = c.execute(f"SELECT * FROM requests WHERE {where_sql}", (value,)).fetchone()
    if r:
        publish({"type": "update", "data": row(r)})

@app.post("/webhooks/razorpay")
def razorpay_webhook():
    body = request.get_data()
    sig = request.headers.get("X-Razorpay-Signature", "")
    expected = hmac.new(RZP_WEBHOOK_SECRET.encode(), body, hashlib.sha256).hexdigest()
    if not RZP_WEBHOOK_SECRET or not hmac.compare_digest(sig, expected):
        abort(400)
    evt = json.loads(body)
    if evt.get("event") == "payment_link.paid":
        link_id = evt["payload"]["payment_link"]["entity"]["id"]
        mark_paid("link_id=?", link_id)
    return "ok"

# ---------------------------------------------------------------- dashboard + API
@app.get("/")
@dashboard
def index():
    return render_template("dashboard.html", demo=DEMO)

@app.get("/api/requests")
@dashboard
def api_requests():
    rows = db().execute("SELECT * FROM requests ORDER BY id DESC LIMIT 100").fetchall()
    return jsonify([dict(r) for r in rows])

# ---------------------------------------------------------------- demo mode (no Twilio/Razorpay needed)
if DEMO:
    @app.post("/demo/call")
    @dashboard
    def demo_call():
        """Simulates what Twilio does: a call from <caller> entering <amount>."""
        with app.test_request_context("/voice/amount", method="POST",
                data={"From": request.form["caller"], "Digits": request.form["amount"]}):
            voice_amount.__wrapped__()
        return ("", 204)

    @app.get("/demo/pay/<int:rid>")
    def demo_pay(rid):
        mark_paid("id=?", rid)
        return "<h2 style='font-family:sans-serif'>Demo payment successful. You can close this tab.</h2>"

init_db()
if __name__ == "__main__":
    app.run(debug=True, threaded=True, port=5000)

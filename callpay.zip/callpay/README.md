# CallPay – receive payments by phone call, see them live

**Flow:** caller dials your number → IVR asks for amount → payment link is SMSed to the caller →
dashboard instantly shows *caller number + amount* → status flips to **PAID** when they pay.

## 1. Try it in 1 minute (demo mode, no accounts needed)
```bash
python -m venv venv && source venv/bin/activate      # Windows: venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env                                  # keeps DEMO_MODE=1
python app.py
```
Open http://localhost:5000 (login: `admin` / `change-me`), click **Simulate incoming call**,
then open the row's *link* to "pay". Everything updates live.

## 2. Go live (real calls + real money, India)
1. **Twilio**: buy a voice number (Indian numbers need regulatory documents). Set *A call comes in* →
   `POST https://YOUR_PUBLIC_URL/voice`. Put your Auth Token in `.env`.
2. **Razorpay**: complete KYC, put `RAZORPAY_KEY_ID/SECRET` in `.env`.
   Add webhook `https://YOUR_PUBLIC_URL/webhooks/razorpay`, event **payment_link.paid**,
   and copy its secret to `RAZORPAY_WEBHOOK_SECRET`.
   *Enable SMS notify for Payment Links in the Razorpay dashboard.*
3. Set `PUBLIC_BASE_URL`, change `DASHBOARD_PASSWORD`, set `DEMO_MODE=0`.
4. For local testing expose the app with `ngrok http 5000`.
5. Production run (single worker so live events work):
   `gunicorn -w 1 --threads 8 -b 0.0.0.0:8000 app:app` behind HTTPS.

## Files
| File | Purpose |
|---|---|
| `app.py` | IVR webhooks, payment link creation, Razorpay webhook, live SSE feed, API |
| `templates/dashboard.html` | Live dashboard with pop-up alerts |
| `.env.example` | All settings |

## Safety built in
Twilio signature check · Razorpay webhook HMAC check · dashboard login · amount cap (`MAX_AMOUNT_INR`) ·
payment links expire in 30 min · the payer always confirms on Razorpay's own page.
